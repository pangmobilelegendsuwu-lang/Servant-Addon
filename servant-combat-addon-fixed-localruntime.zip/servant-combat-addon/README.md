# Servant Combat Style (addon for Servant 0.2.0-release.1)

NeoForge 1.21.1 / Java 21. Does NOT need Epic Fight to compile. Epic Fight is only an optional runtime dependency.

## Build
1. Copy the Servant jar into `libs/`
2. `./gradlew build` (use the gradle wrapper from your other mod project if this folder has none)
3. Jar is in `build/libs/servantcombat-1.1.0.jar`. Put it in `mods/` next to Servant (+ Epic Fight).

## Config  (`config/servantcombat-common.toml`)
`moveset = "EPIC_FIGHT"` (default) or `"VANILLA"`.
Dedicated server: same value on the server and on every client.

## What VANILLA does
- Epic Fight no longer renders/animates servants -> normal vanilla player model (vanilla sit / sleep / swing / walk).
- Epic Fight attack, dodge, guard and its +1.2 attack-speed bonus are turned off (mixins into ServantPatch / ServantGuard).
- Servant mod's own vanilla melee runs again, including its existing Java-style sweeping attack.
- Weapon parry (GUARD/FOLLOW): chance scales with level, normal block = 25% damage, perfect parry from level 30 (negates hit, staggers attacker).
- Dash back / left / right when an enemy is in melee range or right after being hit (archers keep the Servant mod's own dash).
- Attack speed grows with level (extra on top of the Servant mod's own scaling).
- Basic attacks per weapon type (attack speed / damage / reach / sweep damage), all in `[vanilla_weapon_stats]`:
  dagger = fastest, short reach; sword = baseline; uchigatana = quick, medium reach; spear = long reach;
  tachi = slower, strong, long reach; longsword = slower, long reach, better sweep;
  greatsword = slowest, hardest hits, longest reach, strongest sweep.
  These stack on top of the item's own attributes (a modded weapon that is already slow gets slower).
- **Creeper evade** (`[vanilla_creeper_evade]`): the servant attacks the creeper, and once the creeper has been swelling
  for 10 ticks (of its 30) and is within 6.5 blocks, it dashes straight away from it (about 6 blocks, around obstacles,
  never off a ledge or into liquid) while still facing it. It will not walk back in while the creeper is still swelling.
  Works for every servant, archers included.
- **Backward footwork** (`[vanilla_backpedal]`): melee servants walk backward (with a small sideways step) while their
  attack recharges, then step back in for the next hit. The spacing scales with the weapon's reach.
- **Level-based crits** (`[vanilla_crit]`): every melee hit rolls a crit chance, 5% at level 1 up to 45% at level 50, x1.5
  damage, with crit particles and sound. No jumping needed, it works on the ground. Innate skills do not roll crits.
- **Archers**: the Servant mod's own bow AI already walks away when a target is within 6 blocks (10 for creepers) and
  keeps drawing and shooting while it moves. The addon does not change that.
- **Rapid shot** (`[rapid_shot]`, bows only): the archer draws for 2 seconds, then fires a volley. Level 1 = 3 arrows
  0.6 s apart, level 50 = 6 arrows 0.3 s apart (linear in between). Cooldown 8 s at level 1, 40% shorter at level 50.
  Each arrow uses one arrow from the servant and 1 durability from the bow. Movement is not touched, so it keeps retreating
  while it charges and fires.
- Innate weapon skills (cooldown + energy, scale with level), detected from the weapon's item id:
  sword = triple slash, dagger = step-in flurry, spear = piercing thrust, longsword = rising slash + air hit,
  greatsword = earthshatter slam, tachi = double crescent cut, uchigatana = battojutsu dash cut (bleed).
  A weapon counts as a type when its id path contains the keyword (`iron_greatsword`, `somemod:holy_tachi`).
  Keyword lists are in the config (`[vanilla_innate_skills]`); checked most-specific first so greatsword never becomes sword.
All numbers are in the config.

## Not tested (could not build/run in my sandbox)
- 1.1.0 (creeper evade, backward footwork, crits, rapid shot) was written against the Servant jar's bytecode with no compiler available, so it has not been compiled or run. Two new mixins (`ServantMeleeGoalMixin`, `ServantRangedMixin`) hook `GuardMeleeAttackGoal.updatePathToTarget` and `ServantEntity.performRangedAttack`.
- Written against the decompiled Servant jar only. No Epic Fight classes are touched.
- If Epic Fight still plays a hit-stun on servants in VANILLA mode, that needs an Epic Fight-side hook (send me the EF jar then).
