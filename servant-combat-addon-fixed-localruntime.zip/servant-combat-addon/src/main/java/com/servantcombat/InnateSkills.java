package com.servantcombat;

import com.asashiin.servant.entity.ServantEntity;
import com.asashiin.servant.entity.ServantOrder;
import com.asashiin.servant.level.ServantLevels;
import com.asashiin.servant.modes.ServantBow;
import com.asashiin.servant.revive.ServantRevive;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ProjectileWeaponItem;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Innate weapon skills for VANILLA mode. The weapon type is detected from the item id path
 * (e.g. "iron_greatsword", "somemod:holy_tachi"), keywords are configurable.
 */
public final class InnateSkills {
    public enum Weapon { UCHIGATANA, TACHI, GREATSWORD, LONGSWORD, DAGGER, SPEAR, SWORD }

    /** Most specific first, so "greatsword" is never read as "sword". */
    private static final Weapon[] ORDER = {
        Weapon.UCHIGATANA, Weapon.TACHI, Weapon.GREATSWORD, Weapon.LONGSWORD, Weapon.DAGGER, Weapon.SPEAR, Weapon.SWORD
    };
    private static final String NBT_READY = "sc_skill_ready";

    /** True while a skill is dealing its own damage (server thread only), so the crit roll skips it. */
    private static boolean SKILL_STRIKE;

    public static boolean inSkillStrike() {
        return SKILL_STRIKE;
    }

    private static final class Pending {
        int delay;
        final Runnable action;

        Pending(int delay, Runnable action) {
            this.delay = delay;
            this.action = action;
        }
    }

    private static final Map<ServantEntity, List<Pending>> PENDING = new WeakHashMap<>();
    private static final Map<String, String[]> KEYWORD_CACHE = new HashMap<>();

    private InnateSkills() {}

    // ---------------------------------------------------------------- detection

    public static Weapon detect(ItemStack stack) {
        if (stack.isEmpty() || stack.getItem() instanceof ProjectileWeaponItem) {
            return null;
        }
        String path = BuiltInRegistries.ITEM.getKey(stack.getItem()).getPath().toLowerCase(Locale.ROOT);
        for (Weapon weapon : ORDER) {
            for (String keyword : keywords(weapon)) {
                if (!keyword.isEmpty() && path.contains(keyword)) {
                    return weapon;
                }
            }
        }
        return null;
    }

    private static String[] keywords(Weapon weapon) {
        String raw = ServantCombatConfig.keywords(weapon);
        return KEYWORD_CACHE.computeIfAbsent(raw, r -> {
            String[] parts = r.toLowerCase(Locale.ROOT).split(",");
            for (int i = 0; i < parts.length; i++) {
                parts[i] = parts[i].trim();
            }
            return parts;
        });
    }

    private static double minRange(Weapon w) {
        return switch (w) {
            case UCHIGATANA -> 2.0;
            case SPEAR -> 1.5;
            case TACHI -> 1.0;
            default -> 0.0;
        };
    }

    private static double maxRange(Weapon w) {
        return switch (w) {
            case UCHIGATANA -> 5.5;
            case SPEAR -> 5.0;
            case TACHI, LONGSWORD -> 4.0;
            case GREATSWORD, SWORD -> 3.5;
            case DAGGER -> 3.0;
        };
    }

    // ---------------------------------------------------------------- tick / scheduling

    public static boolean busy(ServantEntity servant) {
        List<Pending> list = PENDING.get(servant);
        return list != null && !list.isEmpty();
    }

    public static void tick(ServantEntity servant) {
        runPending(servant);
        if (!ServantCombatConfig.SKILLS.get()) {
            return;
        }
        CompoundTag data = servant.getPersistentData();
        long now = servant.level().getGameTime();
        if (now < data.getLong(NBT_READY) || busy(servant)) {
            return;
        }
        if (!servant.onGround() || servant.isPassenger() || servant.isInWater() || servant.isUsingItem() || servant.isSleeping()) {
            return;
        }
        if (ServantRevive.isDowned(servant)) {
            return;
        }
        ServantOrder order = servant.getCurrentOrder();
        if (order == ServantOrder.PRISONER || order == ServantOrder.STAY || order == ServantOrder.WORKSTATION) {
            return;
        }
        LivingEntity target = servant.getTarget();
        if (target == null || !target.isAlive()) {
            return;
        }
        Weapon weapon = detect(servant.getMainHandItem());
        if (weapon == null) {
            return;
        }
        double dx = target.getX() - servant.getX();
        double dz = target.getZ() - servant.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz) - target.getBbWidth() * 0.5;
        if (dist < minRange(weapon) || dist > maxRange(weapon) || Math.abs(target.getY() - servant.getY()) > 2.5) {
            return;
        }
        if (!servant.hasLineOfSight(target) || ServantLevels.level(servant) < ServantCombatConfig.SKILL_MIN_LEVEL.get()) {
            return;
        }
        if (servant.getRandom().nextDouble() >= ServantCombatConfig.SKILL_CHANCE_PER_TICK.get()) {
            return;
        }
        if (!ServantBow.spend(servant, ServantCombatConfig.SKILL_ENERGY_COST.get())) {
            return;
        }

        face(servant, target);
        cast(weapon, servant, target);

        double progress = Mth.clamp((ServantLevels.level(servant) - 1) / (double) (ServantLevels.MAX_LEVEL - 1), 0.0, 1.0);
        double cooldown = ServantCombatConfig.SKILL_COOLDOWN.get()
            * (1.0 - ServantCombatConfig.SKILL_COOLDOWN_REDUCTION_AT_MAX_LEVEL.get() * progress);
        data.putLong(NBT_READY, now + Math.max(20L, Math.round(cooldown)));
    }

    private static void later(ServantEntity servant, int delay, Runnable action) {
        if (delay <= 0) {
            action.run();
        } else {
            PENDING.computeIfAbsent(servant, k -> new ArrayList<>()).add(new Pending(delay, action));
        }
    }

    private static void runPending(ServantEntity servant) {
        List<Pending> list = PENDING.get(servant);
        if (list == null) {
            return;
        }
        if (!servant.isAlive() || ServantRevive.isDowned(servant)) {
            PENDING.remove(servant);
            return;
        }
        List<Runnable> due = new ArrayList<>();
        Iterator<Pending> it = list.iterator();
        while (it.hasNext()) {
            Pending p = it.next();
            if (--p.delay <= 0) {
                due.add(p.action);
                it.remove();
            }
        }
        if (list.isEmpty()) {
            PENDING.remove(servant);
        }
        for (Runnable r : due) {
            r.run();
        }
    }

    // ---------------------------------------------------------------- skills

    private static void cast(Weapon weapon, ServantEntity s, LivingEntity t) {
        switch (weapon) {
            case SWORD -> tripleSlash(s, t);
            case DAGGER -> flurry(s, t);
            case SPEAR -> piercingThrust(s, t);
            case LONGSWORD -> risingSlash(s, t);
            case GREATSWORD -> earthshatter(s, t);
            case TACHI -> moonArc(s, t);
            case UCHIGATANA -> battojutsu(s, t);
        }
    }

    /** SWORD: three quick cone slashes, the last one knocks back. */
    private static void tripleSlash(ServantEntity s, LivingEntity t) {
        for (int i = 0; i < 3; i++) {
            final boolean last = i == 2;
            later(s, i * 6, () -> slash(s, t, 3.6, 0.3, last ? 1.0F : 0.7F, last ? 0.8 : 0.0));
        }
    }

    /** DAGGER: step in, then four fast stabs. */
    private static void flurry(ServantEntity s, LivingEntity t) {
        lunge(s, t, 0.5);
        for (int i = 0; i < 4; i++) {
            final boolean last = i == 3;
            later(s, 1 + i * 2, () -> {
                if (!t.isAlive()) {
                    return;
                }
                face(s, t);
                s.swing(InteractionHand.MAIN_HAND, true);
                strike(s, t, 0.5F, last ? 0.5 : 0.0);
                particles(s, ParticleTypes.CRIT, t.position().add(0, t.getBbHeight() * 0.6, 0), 4, 0.25, 0.1);
                sound(s, SoundEvents.PLAYER_ATTACK_CRIT, 0.7F, 1.4F);
            });
        }
    }

    /** SPEAR: lunge forward, then a long piercing thrust through everything in a line. */
    private static void piercingThrust(ServantEntity s, LivingEntity t) {
        lunge(s, t, 1.1);
        later(s, 3, () -> {
            if (t.isAlive()) {
                face(s, t);
            }
            Vec3 fwd = forward(s);
            s.swing(InteractionHand.MAIN_HAND, true);
            for (LivingEntity e : line(s, fwd, 4.5, 0.9)) {
                strike(s, e, 1.3F, 0.8);
            }
            lineParticles(s, fwd, 4.0, ParticleTypes.CRIT);
            sound(s, SoundEvents.PLAYER_ATTACK_STRONG, 1.0F, 1.2F);
        });
    }

    /** LONGSWORD: big upward slash that launches enemies, followed by an air hit. */
    private static void risingSlash(ServantEntity s, LivingEntity t) {
        lunge(s, t, 0.4);
        later(s, 2, () -> {
            List<LivingEntity> hit = slash(s, t, 4.0, 0.3, 1.2F, 0.0);
            for (LivingEntity e : hit) {
                Vec3 v = e.getDeltaMovement();
                e.setDeltaMovement(v.x * 0.3, 0.55, v.z * 0.3);
                e.hurtMarked = true;
            }
            later(s, 8, () -> {
                s.swing(InteractionHand.MAIN_HAND, true);
                for (LivingEntity e : hit) {
                    if (e.isAlive()) {
                        strike(s, e, 0.8F, 0.0);
                        particles(s, ParticleTypes.CRIT, e.position().add(0, e.getBbHeight() * 0.5, 0), 6, 0.3, 0.2);
                    }
                }
                sound(s, SoundEvents.PLAYER_ATTACK_CRIT, 1.0F, 0.9F);
            });
        });
    }

    /** GREATSWORD: slow wind-up, then a ground slam that hits everything around the servant. */
    private static void earthshatter(ServantEntity s, LivingEntity t) {
        s.getNavigation().stop();
        s.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 14, 6, false, false));
        particles(s, ParticleTypes.CRIT, s.position().add(0, 2.0, 0), 8, 0.3, 0.1);
        sound(s, SoundEvents.PLAYER_ATTACK_KNOCKBACK, 0.8F, 0.6F);
        later(s, 10, () -> {
            s.swing(InteractionHand.MAIN_HAND, true);
            for (LivingEntity e : cone(s, forward(s), 3.8, -1.0)) {
                if (strike(s, e, 1.6F, 1.0)) {
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1));
                }
            }
            particles(s, ParticleTypes.EXPLOSION, s.position().add(0, 0.3, 0), 3, 1.2, 0.0);
            particles(s, ParticleTypes.CLOUD, s.position().add(0, 0.2, 0), 24, 1.5, 0.08);
            sound(s, SoundEvents.ANVIL_LAND, 1.0F, 0.6F);
        });
    }

    /** TACHI: step in, then two wide crescent cuts. */
    private static void moonArc(ServantEntity s, LivingEntity t) {
        lunge(s, t, 0.7);
        later(s, 3, () -> slash(s, t, 4.5, -0.2, 1.1F, 0.4));
        later(s, 8, () -> slash(s, t, 4.5, -0.2, 1.1F, 0.9));
    }

    /** UCHIGATANA: sheathe and wait, then dash through the line for one heavy cut that leaves a bleed. */
    private static void battojutsu(ServantEntity s, LivingEntity t) {
        s.getNavigation().stop();
        s.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10, 6, false, false));
        particles(s, ParticleTypes.CRIT, s.position().add(0, 1.0, 0), 6, 0.3, 0.05);
        sound(s, SoundEvents.PLAYER_ATTACK_CRIT, 0.6F, 0.6F);
        later(s, 8, () -> {
            if (t.isAlive()) {
                lunge(s, t, 1.5);
            }
        });
        later(s, 11, () -> {
            if (t.isAlive()) {
                face(s, t);
            }
            Vec3 fwd = forward(s);
            s.swing(InteractionHand.MAIN_HAND, true);
            for (LivingEntity e : line(s, fwd, 5.0, 1.0)) {
                if (strike(s, e, 2.0F, 0.6)) {
                    e.addEffect(new MobEffectInstance(MobEffects.WITHER, 60, 0));
                }
            }
            lineParticles(s, fwd, 5.0, ParticleTypes.SWEEP_ATTACK);
            sound(s, SoundEvents.PLAYER_ATTACK_SWEEP, 1.0F, 1.6F);
        });
    }

    // ---------------------------------------------------------------- helpers

    /** One arc slash in front of the servant. Returns the entities that were hurt. */
    private static List<LivingEntity> slash(ServantEntity s, LivingEntity t, double range, double minDot, float mult, double knockback) {
        if (t != null && t.isAlive()) {
            face(s, t);
        }
        Vec3 fwd = forward(s);
        s.swing(InteractionHand.MAIN_HAND, true);
        particles(s, ParticleTypes.SWEEP_ATTACK, s.position().add(fwd.x * 1.2, 1.0, fwd.z * 1.2), 1, 0.0, 0.0);
        sound(s, SoundEvents.PLAYER_ATTACK_SWEEP, 1.0F, 1.0F);
        List<LivingEntity> hit = new ArrayList<>();
        for (LivingEntity e : cone(s, fwd, range, minDot)) {
            if (strike(s, e, mult, knockback)) {
                hit.add(e);
            }
        }
        return hit;
    }

    private static boolean valid(ServantEntity s, LivingEntity e) {
        return e != s && e.isAlive() && !(e instanceof ServantEntity) && !s.isAlliedTo(e)
            && (e == s.getTarget() || e instanceof Enemy);
    }

    private static boolean strike(ServantEntity s, LivingEntity target, float mult, double knockback) {
        if (!valid(s, target)) {
            return false;
        }
        float base = Math.max(1.0F, (float) s.getAttributeValue(Attributes.ATTACK_DAMAGE));
        target.invulnerableTime = 0; // multi-hit skills must not be eaten by i-frames
        boolean hurt;
        SKILL_STRIKE = true; // skills never roll the level-based melee crit
        try {
            hurt = target.hurt(s.damageSources().mobAttack(s), base * mult * ServantCombatConfig.SKILL_DAMAGE_MULTIPLIER.get().floatValue());
        } finally {
            SKILL_STRIKE = false;
        }
        if (hurt && knockback > 0.0) {
            float yaw = s.getYRot() * ((float) Math.PI / 180.0F);
            target.knockback(knockback, Mth.sin(yaw), -Mth.cos(yaw));
        }
        return hurt;
    }

    private static List<LivingEntity> cone(ServantEntity s, Vec3 fwd, double range, double minDot) {
        List<LivingEntity> out = new ArrayList<>();
        AABB box = s.getBoundingBox().inflate(range, 1.5, range);
        for (LivingEntity e : s.level().getEntitiesOfClass(LivingEntity.class, box)) {
            if (!valid(s, e)) {
                continue;
            }
            double dx = e.getX() - s.getX();
            double dz = e.getZ() - s.getZ();
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d - e.getBbWidth() * 0.5 > range) {
                continue;
            }
            if (d > 0.001 && (dx * fwd.x + dz * fwd.z) / d < minDot) {
                continue;
            }
            out.add(e);
        }
        return out;
    }

    private static List<LivingEntity> line(ServantEntity s, Vec3 fwd, double length, double width) {
        List<LivingEntity> out = new ArrayList<>();
        AABB box = s.getBoundingBox().inflate(length, 1.5, length);
        for (LivingEntity e : s.level().getEntitiesOfClass(LivingEntity.class, box)) {
            if (!valid(s, e)) {
                continue;
            }
            double dx = e.getX() - s.getX();
            double dz = e.getZ() - s.getZ();
            double along = dx * fwd.x + dz * fwd.z;
            double across = Math.abs(fwd.x * dz - fwd.z * dx);
            if (along < -0.3 || along > length || across > width + e.getBbWidth() * 0.5) {
                continue;
            }
            out.add(e);
        }
        return out;
    }

    private static Vec3 forward(ServantEntity s) {
        float yaw = s.getYRot() * ((float) Math.PI / 180.0F);
        return new Vec3(-Mth.sin(yaw), 0.0, Mth.cos(yaw));
    }

    private static void face(ServantEntity s, LivingEntity t) {
        double dx = t.getX() - s.getX();
        double dz = t.getZ() - s.getZ();
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0F;
        s.setYRot(yaw);
        s.yBodyRot = yaw;
        s.yHeadRot = yaw;
    }

    private static void lunge(ServantEntity s, LivingEntity t, double strength) {
        Vec3 to = new Vec3(t.getX() - s.getX(), 0.0, t.getZ() - s.getZ());
        if (to.lengthSqr() < 1.0E-4) {
            return;
        }
        Vec3 d = to.normalize();
        face(s, t);
        s.getNavigation().stop();
        s.setDeltaMovement(d.x * strength, 0.1, d.z * strength);
        s.hurtMarked = true;
    }

    private static void lineParticles(ServantEntity s, Vec3 fwd, double length, ParticleOptions particle) {
        for (double d = 0.8; d <= length; d += 0.8) {
            particles(s, particle, s.position().add(fwd.x * d, 1.1, fwd.z * d), 1, 0.1, 0.0);
        }
    }

    private static void particles(ServantEntity s, ParticleOptions particle, Vec3 pos, int count, double spread, double speed) {
        if (s.level() instanceof ServerLevel level) {
            level.sendParticles(particle, pos.x, pos.y, pos.z, count, spread, spread * 0.5, spread, speed);
        }
    }

    private static void sound(ServantEntity s, SoundEvent event, float volume, float pitch) {
        s.level().playSound(null, s.getX(), s.getY(), s.getZ(), event, SoundSource.HOSTILE, volume, pitch);
    }
}
