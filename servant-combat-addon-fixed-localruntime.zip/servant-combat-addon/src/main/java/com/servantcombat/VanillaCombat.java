package com.servantcombat;

import com.asashiin.servant.entity.ServantEntity;
import com.asashiin.servant.entity.ServantOrder;
import com.asashiin.servant.level.ServantLevels;
import com.asashiin.servant.modes.ServantBow;
import com.asashiin.servant.compat.ServantPlayerProxyRegistry;
import com.asashiin.servant.revive.ServantRevive;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ProjectileWeaponItem;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

/**
 * Vanilla moveset extras for servants: weapon parry, dash back / left / right,
 * level-based attack speed. Sweeping attacks already exist in the Servant mod's own melee code and
 * run as soon as the Epic Fight attack hook is switched off (see ServantPatchMixin).
 */
public final class VanillaCombat {
    private static final ResourceLocation EF_SPEED_ID = ResourceLocation.fromNamespaceAndPath("servant", "epicfight_attack_speed");
    private static final ResourceLocation LEVEL_SPEED_ID = ResourceLocation.fromNamespaceAndPath(ServantCombat.MOD_ID, "vanilla_level_attack_speed");
    private static final ResourceLocation W_SPEED_ID = ResourceLocation.fromNamespaceAndPath(ServantCombat.MOD_ID, "weapon_attack_speed");
    private static final ResourceLocation W_DAMAGE_ID = ResourceLocation.fromNamespaceAndPath(ServantCombat.MOD_ID, "weapon_damage");
    private static final ResourceLocation W_REACH_ID = ResourceLocation.fromNamespaceAndPath(ServantCombat.MOD_ID, "weapon_reach");
    private static final ResourceLocation W_SWEEP_ID = ResourceLocation.fromNamespaceAndPath(ServantCombat.MOD_ID, "weapon_sweep");
    private static final String NBT_DASH_READY = "sc_dash_ready";
    private static final String NBT_PARRY_LAST = "sc_parry_last";
    private static final String NBT_CREEPER_DASH_READY = "sc_creeper_dash_ready";

    /** creeper -> {first tick seen swelling, last tick seen swelling}. Server thread only. */
    private static final Map<Creeper, long[]> FUSES = new WeakHashMap<>();

    private VanillaCombat() {}

    public static void register() {
        NeoForge.EVENT_BUS.addListener(EventPriority.HIGH, VanillaCombat::onIncomingDamage);
        NeoForge.EVENT_BUS.addListener(VanillaCombat::onEntityTick);
        NeoForge.EVENT_BUS.addListener(VanillaCombat::onCritRoll);
    }

    static double progress(ServantEntity servant) {
        int level = ServantLevels.level(servant);
        return Mth.clamp((level - 1) / (double) (ServantLevels.MAX_LEVEL - 1), 0.0, 1.0);
    }

    // ---------------------------------------------------------------- tick

    private static void onEntityTick(EntityTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServantEntity servant) || servant.level().isClientSide() || !servant.isAlive()) {
            return;
        }
        if (servant.tickCount % 10 == 0) {
            syncAttackSpeed(servant);
            syncWeaponStats(servant);
        }
        if (ServantCombatConfig.vanilla()) {
            InnateSkills.tick(servant);
            if (ServantCombatConfig.CREEPER_EVADE.get()) {
                tickCreeperEvade(servant);
            }
            if (ServantCombatConfig.DASH.get()) {
                tickDash(servant);
            }
        }
        RapidShot.tick(servant);
    }

    /** Vanilla mode: drop the Epic Fight speed bonus and add level scaling. Epic Fight mode: remove our modifier. */
    private static void syncAttackSpeed(ServantEntity servant) {
        AttributeInstance speed = servant.getAttribute(Attributes.ATTACK_SPEED);
        if (speed == null) {
            return;
        }
        if (!ServantCombatConfig.vanilla()) {
            if (speed.getModifier(LEVEL_SPEED_ID) != null) {
                speed.removeModifier(LEVEL_SPEED_ID);
            }
            return;
        }
        if (speed.getModifier(EF_SPEED_ID) != null) {
            speed.removeModifier(EF_SPEED_ID);
        }
        double want = ServantCombatConfig.ATTACK_SPEED_BONUS_AT_MAX_LEVEL.get() * progress(servant);
        AttributeModifier current = speed.getModifier(LEVEL_SPEED_ID);
        if (want <= 0.0) {
            if (current != null) {
                speed.removeModifier(LEVEL_SPEED_ID);
            }
        } else if (current == null || Math.abs(current.amount() - want) > 1.0E-4) {
            speed.addOrUpdateTransientModifier(
                new AttributeModifier(LEVEL_SPEED_ID, want, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
    }

    /** Per weapon type attack speed / damage / reach / sweep (VANILLA mode only; removed again in Epic Fight mode). */
    private static void syncWeaponStats(ServantEntity servant) {
        InnateSkills.Weapon weapon = null;
        if (ServantCombatConfig.vanilla() && ServantCombatConfig.WEAPON_STATS.get()) {
            weapon = InnateSkills.detect(servant.getMainHandItem());
        }
        boolean on = weapon != null;
        setModifier(servant.getAttribute(Attributes.ATTACK_SPEED), W_SPEED_ID,
            on ? ServantCombatConfig.stat(weapon, 0) - 1.0 : 0.0, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
        setModifier(servant.getAttribute(Attributes.ATTACK_DAMAGE), W_DAMAGE_ID,
            on ? ServantCombatConfig.stat(weapon, 1) - 1.0 : 0.0, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL);
        setModifier(servant.getAttribute(Attributes.ENTITY_INTERACTION_RANGE), W_REACH_ID,
            on ? ServantCombatConfig.stat(weapon, 2) : 0.0, AttributeModifier.Operation.ADD_VALUE);
        setModifier(servant.getAttribute(Attributes.SWEEPING_DAMAGE_RATIO), W_SWEEP_ID,
            on ? ServantCombatConfig.stat(weapon, 3) : 0.0, AttributeModifier.Operation.ADD_VALUE);
    }

    private static void setModifier(AttributeInstance attribute, ResourceLocation id, double amount, AttributeModifier.Operation op) {
        if (attribute == null) {
            return;
        }
        AttributeModifier current = attribute.getModifier(id);
        if (Math.abs(amount) < 1.0E-6) {
            if (current != null) {
                attribute.removeModifier(id);
            }
        } else if (current == null || Math.abs(current.amount() - amount) > 1.0E-6) {
            attribute.addOrUpdateTransientModifier(new AttributeModifier(id, amount, op));
        }
    }

    // ---------------------------------------------------------------- dash

    private static void tickDash(ServantEntity servant) {
        CompoundTag data = servant.getPersistentData();
        long now = servant.level().getGameTime();
        if (now < data.getLong(NBT_DASH_READY)) {
            return;
        }
        if (!servant.onGround() || servant.isPassenger() || servant.isInWater() || servant.isUsingItem() || servant.isSleeping()) {
            return;
        }
        if (InnateSkills.busy(servant)) {
            return; // mid-skill
        }
        if (ServantRevive.isDowned(servant) || ServantBow.bowHand(servant) != null) {
            return; // archers already have the Servant mod's own dash
        }
        ServantOrder order = servant.getCurrentOrder();
        if (order == ServantOrder.PRISONER || order == ServantOrder.STAY || order == ServantOrder.WORKSTATION) {
            return;
        }
        LivingEntity target = servant.getTarget();
        if (target == null || !target.isAlive() || servant.distanceTo(target) > 3.5F) {
            return;
        }

        boolean justHit = servant.hurtTime > 0 && servant.hurtTime >= servant.hurtDuration - 1;
        double chance = justHit
            ? ServantCombatConfig.DASH_CHANCE_WHEN_HIT.get()
            : ServantCombatConfig.DASH_IDLE_CHANCE_PER_TICK.get();
        if (servant.getRandom().nextDouble() >= chance) {
            return;
        }
        if (!ServantBow.spend(servant, ServantCombatConfig.DASH_ENERGY_COST.get())) {
            return;
        }

        Vec3 toTarget = new Vec3(target.getX() - servant.getX(), 0.0, target.getZ() - servant.getZ());
        if (toTarget.lengthSqr() < 1.0E-4) {
            return;
        }
        Vec3 forward = toTarget.normalize();
        Vec3 right = new Vec3(-forward.z, 0.0, forward.x);
        float roll = servant.getRandom().nextFloat();
        Vec3 dir = roll < 0.4F ? right.scale(-1.0) : roll < 0.8F ? right : forward.scale(-1.0);

        face(servant, forward);
        double s = ServantCombatConfig.DASH_STRENGTH.get();
        servant.getNavigation().stop();
        servant.setDeltaMovement(dir.x * s, 0.2, dir.z * s);
        servant.hurtMarked = true;

        int min = ServantCombatConfig.DASH_COOLDOWN_MIN.get();
        int max = Math.max(min, ServantCombatConfig.DASH_COOLDOWN_MAX.get());
        data.putLong(NBT_DASH_READY, now + min + servant.getRandom().nextInt(max - min + 1));

        if (servant.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.CLOUD, servant.getX(), servant.getY() + 0.1, servant.getZ(), 6, 0.2, 0.05, 0.2, 0.02);
            level.playSound(null, servant.getX(), servant.getY(), servant.getZ(),
                SoundEvents.PLAYER_ATTACK_NODAMAGE, SoundSource.NEUTRAL, 0.8F, 1.4F);
        }
    }

    private static void face(ServantEntity servant, Vec3 towardTarget) {
        float yaw = (float) (Mth.atan2(towardTarget.z, towardTarget.x) * (180.0 / Math.PI)) - 90.0F;
        servant.setYRot(yaw);
        servant.yBodyRot = yaw;
        servant.yHeadRot = yaw;
    }

    // ---------------------------------------------------------------- creeper evade

    /** Ticks this creeper has been swelling (0 when it is not). Keeps the first-seen tick in {@link #FUSES}. */
    private static int fuseTicks(Creeper creeper, long now) {
        long[] f = FUSES.get(creeper);
        if (f == null || now - f[1] > 6L) {
            f = new long[] {now, now};
            FUSES.put(creeper, f);
        }
        f[1] = now;
        return (int) (now - f[0]);
    }

    private static boolean swelling(Creeper creeper) {
        return creeper.isAlive() && (creeper.getSwellDir() > 0 || creeper.isIgnited());
    }

    /** True while this creeper has been swelling long enough that servants must stay away from it. */
    public static boolean creeperDanger(Creeper creeper) {
        if (!swelling(creeper)) {
            return false;
        }
        return fuseTicks(creeper, creeper.level().getGameTime()) >= ServantCombatConfig.CREEPER_FUSE_THRESHOLD.get();
    }

    private static void tickCreeperEvade(ServantEntity servant) {
        if (servant.tickCount % 2 != 0) {
            return;
        }
        long now = servant.level().getGameTime();
        CompoundTag data = servant.getPersistentData();
        if (now < data.getLong(NBT_CREEPER_DASH_READY)) {
            return;
        }
        if (!servant.onGround() || servant.isPassenger() || servant.isInWater() || servant.isSleeping()
            || ServantRevive.isDowned(servant) || servant.getCurrentOrder() == ServantOrder.PRISONER) {
            return;
        }
        double scan = ServantCombatConfig.CREEPER_DANGER_RADIUS.get() * 1.5 + 1.0;
        List<Creeper> creepers = servant.level().getEntitiesOfClass(Creeper.class,
            servant.getBoundingBox().inflate(scan, 3.0, scan), VanillaCombat::swelling);
        Creeper worst = null;
        double best = Double.MAX_VALUE;
        for (Creeper c : creepers) {
            int fuse = fuseTicks(c, now);
            if (fuse < ServantCombatConfig.CREEPER_FUSE_THRESHOLD.get()) {
                continue;
            }
            double radius = ServantCombatConfig.CREEPER_DANGER_RADIUS.get() * (c.isPowered() ? 1.5 : 1.0);
            double d = servant.distanceTo(c);
            if (d <= radius && d < best) {
                best = d;
                worst = c;
            }
        }
        if (worst == null) {
            return;
        }
        Vec3 away = new Vec3(servant.getX() - worst.getX(), 0.0, servant.getZ() - worst.getZ());
        if (away.lengthSqr() < 1.0E-4) {
            double a = servant.getRandom().nextDouble() * Math.PI * 2.0;
            away = new Vec3(Math.cos(a), 0.0, Math.sin(a));
        }
        away = away.normalize();
        // straight back first, then 45 degrees to either side if something is in the way
        Vec3 dir = null;
        for (double turn : new double[] {0.0, 0.7854, -0.7854}) {
            Vec3 d = rotateY(away, turn);
            if (pathClear(servant, d, 2.2)) {
                dir = d;
                break;
            }
        }
        if (dir == null) {
            return;
        }
        // keep facing the creeper while backing away, like a player would
        face(servant, away.scale(-1.0));
        double strength = ServantCombatConfig.CREEPER_DASH_STRENGTH.get();
        servant.getNavigation().stop();
        servant.getMoveControl().strafe(0.0F, 0.0F);
        servant.setDeltaMovement(dir.x * strength, 0.3, dir.z * strength);
        servant.hurtMarked = true;
        data.putLong(NBT_CREEPER_DASH_READY, now + ServantCombatConfig.CREEPER_DASH_COOLDOWN.get());

        if (servant.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.CLOUD, servant.getX(), servant.getY() + 0.1, servant.getZ(), 8, 0.25, 0.05, 0.25, 0.03);
            level.playSound(null, servant.getX(), servant.getY(), servant.getZ(),
                SoundEvents.PLAYER_ATTACK_NODAMAGE, SoundSource.NEUTRAL, 0.9F, 1.5F);
        }
    }

    private static Vec3 rotateY(Vec3 v, double radians) {
        double cos = Math.cos(radians);
        double sin = Math.sin(radians);
        return new Vec3(v.x * cos - v.z * sin, 0.0, v.x * sin + v.z * cos);
    }

    /** Room to move {@code reach} blocks along {@code dir} without hitting a wall, a drop (more than 2 blocks) or liquid. */
    private static boolean pathClear(ServantEntity servant, Vec3 dir, double reach) {
        if (!servant.level().noCollision(servant, servant.getBoundingBox().move(dir.x * reach * 0.5, 0.0, dir.z * reach * 0.5))) {
            return false;
        }
        BlockPos feet = BlockPos.containing(servant.getX() + dir.x * reach, servant.getY(), servant.getZ() + dir.z * reach);
        if (!servant.level().getFluidState(feet).isEmpty() || !servant.level().getFluidState(feet.below()).isEmpty()) {
            return false;
        }
        for (int i = 1; i <= 2; i++) {
            BlockPos below = feet.below(i);
            BlockState state = servant.level().getBlockState(below);
            if (!state.getCollisionShape(servant.level(), below).isEmpty()) {
                return true;
            }
        }
        return false;
    }

    // ---------------------------------------------------------------- melee spacing (called from ServantMeleeGoalMixin)

    /**
     * Player-like footwork for the Servant mod's melee goal. Returns true when this tick's movement was
     * handled here, in which case the goal must not path toward the target.
     * <ul>
     * <li>Creeper that is close to exploding: do not walk into it. Back off if it is near, otherwise hold position.</li>
     * <li>Any other target: walk backward (with a little side step) while the attack recharges, so the servant
     * "moves backward while attacking". It steps back in for the next hit when the cooldown is nearly over.</li>
     * </ul>
     */
    public static boolean meleeSpacing(ServantEntity servant, LivingEntity target, int cooldownLeft) {
        if (!ServantCombatConfig.vanilla() || servant.level().isClientSide() || target == null || !target.isAlive()) {
            return false;
        }
        if (!servant.onGround() || servant.isPassenger() || servant.isInWater() || servant.isUsingItem()
            || ServantRevive.isDowned(servant) || InnateSkills.busy(servant)) {
            return false;
        }
        if (target instanceof Creeper creeper) {
            if (!ServantCombatConfig.CREEPER_EVADE.get() || !creeperDanger(creeper)) {
                return false;
            }
            double safe = ServantCombatConfig.CREEPER_DANGER_RADIUS.get() * (creeper.isPowered() ? 1.5 : 1.0) + 1.0;
            if (servant.distanceTo(creeper) < safe) {
                retreat(servant, creeper, ServantCombatConfig.BACKPEDAL_SPEED.get() * 1.6, 0.0);
            } else {
                servant.getNavigation().stop();
                servant.getMoveControl().strafe(0.0F, 0.0F);
            }
            return true;
        }
        if (!ServantCombatConfig.BACKPEDAL.get() || cooldownLeft < ServantCombatConfig.BACKPEDAL_MIN_COOLDOWN_LEFT.get()) {
            return false;
        }
        double reach = servant.getAttributeValue(Attributes.ENTITY_INTERACTION_RANGE);
        double limit = reach * ServantCombatConfig.BACKPEDAL_REACH_FRACTION.get();
        if (servant.distanceTo(target) >= limit) {
            return false;
        }
        return retreat(servant, target, ServantCombatConfig.BACKPEDAL_SPEED.get(), ServantCombatConfig.BACKPEDAL_SIDE_STEP.get());
    }

    /** Walks the servant away from {@code from} without turning its back (it keeps facing the target). */
    private static boolean retreat(ServantEntity servant, LivingEntity from, double speed, double sideFactor) {
        Vec3 away = new Vec3(servant.getX() - from.getX(), 0.0, servant.getZ() - from.getZ());
        if (away.lengthSqr() < 1.0E-4) {
            return false;
        }
        away = away.normalize();
        Vec3 side = new Vec3(-away.z, 0.0, away.x);
        int sign = ((servant.getId() + servant.tickCount / 30) & 1) == 0 ? 1 : -1;
        Vec3 dir = away.add(side.scale(sign * sideFactor)).normalize();
        if (!pathClear(servant, dir, 1.4)) {
            dir = away;
            if (!pathClear(servant, dir, 1.4)) {
                return false;
            }
        }
        servant.getNavigation().stop();
        servant.getMoveControl().strafe(0.0F, 0.0F); // drop any pending "walk to target" order
        Vec3 v = servant.getDeltaMovement();
        servant.setDeltaMovement(dir.x * speed, v.y, dir.z * speed);
        return true;
    }

    // ---------------------------------------------------------------- crit

    /** Level-based crit roll for servant melee hits, on the ground included (no jump needed). */
    private static void onCritRoll(LivingIncomingDamageEvent event) {
        if (!ServantCombatConfig.vanilla() || !ServantCombatConfig.CRIT.get() || InnateSkills.inSkillStrike()) {
            return;
        }
        DamageSource source = event.getSource();
        if (!source.is(DamageTypes.MOB_ATTACK) && !source.is(DamageTypes.PLAYER_ATTACK)) {
            return;
        }
        Entity direct = source.getDirectEntity();
        if (direct == null) {
            return;
        }
        ServantEntity servant = null;
        if (direct instanceof ServantEntity s) {
            servant = s;
        } else {
            try {
                servant = ServantPlayerProxyRegistry.resolve(direct); // GUARD melee hits come from the servant's fake player
            } catch (Throwable ignored) {
                // no proxy / registry not ready
            }
        }
        LivingEntity victim = event.getEntity();
        if (servant == null || servant.level().isClientSide() || victim == servant || victim instanceof ServantEntity) {
            return;
        }
        double chance = Mth.lerp(progress(servant), ServantCombatConfig.CRIT_CHANCE_BASE.get(), ServantCombatConfig.CRIT_CHANCE_AT_MAX_LEVEL.get());
        if (servant.getRandom().nextDouble() >= chance) {
            return;
        }
        event.setAmount(event.getAmount() * ServantCombatConfig.CRIT_MULTIPLIER.get().floatValue());
        if (servant.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.CRIT, victim.getX(), victim.getY() + victim.getBbHeight() * 0.6, victim.getZ(),
                14, 0.3, 0.3, 0.3, 0.3);
            level.playSound(null, victim.getX(), victim.getY(), victim.getZ(),
                SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.PLAYERS, 1.0F, 1.0F);
        }
    }

    // ---------------------------------------------------------------- parry

    private static void onIncomingDamage(LivingIncomingDamageEvent event) {
        if (!ServantCombatConfig.vanilla() || !ServantCombatConfig.PARRY.get()) {
            return;
        }
        if (!(event.getEntity() instanceof ServantEntity servant) || servant.level().isClientSide()
            || !servant.isAlive() || ServantRevive.isDowned(servant)) {
            return;
        }
        ServantOrder order = servant.getCurrentOrder();
        if (order != ServantOrder.GUARD && order != ServantOrder.FOLLOW) {
            return;
        }
        DamageSource source = event.getSource();
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || source.is(DamageTypeTags.IS_FALL)
            || source.is(DamageTypeTags.IS_FIRE) || source.is(DamageTypeTags.IS_DROWNING)
            || source.is(DamageTypeTags.IS_EXPLOSION)) {
            return;
        }
        Entity attacker = source.getDirectEntity();
        Vec3 from = source.getSourcePosition();
        if (attacker == null || from == null || servant.isUsingItem() || !isMeleeWeapon(servant.getMainHandItem())) {
            return;
        }

        CompoundTag data = servant.getPersistentData();
        long now = servant.level().getGameTime();
        if (now - data.getLong(NBT_PARRY_LAST) < 10L) {
            return;
        }

        // must be facing the hit
        Vec3 to = from.subtract(servant.position());
        Vec3 look = servant.getLookAngle();
        double flat = Math.sqrt(to.x * to.x + to.z * to.z);
        if (flat > 0.001) {
            double lookFlat = Math.max(0.001, Math.sqrt(look.x * look.x + look.z * look.z));
            if ((to.x * look.x + to.z * look.z) / (flat * lookFlat) < 0.15) {
                return;
            }
        }

        double p = progress(servant);
        double chance = Mth.lerp(p, ServantCombatConfig.PARRY_BASE_CHANCE.get(), ServantCombatConfig.PARRY_CHANCE_AT_MAX_LEVEL.get());
        if (servant.getRandom().nextDouble() > chance) {
            return;
        }
        int cost = (int) Math.round(ServantBow.maxEnergy(servant) * ServantCombatConfig.PARRY_ENERGY_COST_PERCENT.get());
        if (!ServantBow.spend(servant, cost)) {
            return;
        }
        data.putLong(NBT_PARRY_LAST, now);

        boolean perfect = ServantLevels.level(servant) >= ServantCombatConfig.PERFECT_PARRY_MIN_LEVEL.get()
            && servant.getRandom().nextDouble() < ServantCombatConfig.PERFECT_PARRY_CHANCE.get();

        servant.swing(InteractionHand.MAIN_HAND, true); // vanilla arm swing = the parry motion
        ServerLevel level = (ServerLevel) servant.level();

        if (perfect) {
            level.sendParticles(ParticleTypes.CRIT, servant.getX(), servant.getY() + 1.2, servant.getZ(), 16, 0.4, 0.4, 0.4, 0.25);
            level.playSound(null, servant.getX(), servant.getY(), servant.getZ(),
                SoundEvents.ANVIL_PLACE, SoundSource.HOSTILE, 0.5F, 2.0F);
            if (attacker instanceof Projectile) {
                attacker.discard();
            } else if (attacker instanceof LivingEntity living) {
                living.knockback(0.9, -to.x, -to.z);
                living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 50, 3));
                living.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 1));
            }
            event.setCanceled(true);
        } else {
            level.sendParticles(ParticleTypes.CRIT, servant.getX(), servant.getY() + 1.2, servant.getZ(), 6, 0.3, 0.3, 0.3, 0.1);
            level.playSound(null, servant.getX(), servant.getY(), servant.getZ(),
                SoundEvents.SHIELD_BLOCK, SoundSource.HOSTILE, 1.0F, 1.0F);
            event.setAmount(event.getAmount() * ServantCombatConfig.BLOCKED_DAMAGE_MULTIPLIER.get().floatValue());
        }
    }

    /** Anything held in the main hand that adds attack damage and isn't a bow/crossbow. */
    private static boolean isMeleeWeapon(ItemStack stack) {
        if (stack.isEmpty() || stack.getItem() instanceof ProjectileWeaponItem) {
            return false;
        }
        boolean[] melee = {false};
        stack.forEachModifier(EquipmentSlot.MAINHAND, (attribute, modifier) -> {
            if (attribute.equals(Attributes.ATTACK_DAMAGE) && modifier.amount() > 0.0) {
                melee[0] = true;
            }
        });
        return melee[0];
    }
}
