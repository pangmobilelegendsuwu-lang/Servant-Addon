package com.servantcombat;

import com.asashiin.servant.entity.ServantEntity;
import com.asashiin.servant.entity.ServantOrder;
import com.asashiin.servant.level.ServantLevels;
import com.asashiin.servant.modes.ServantBow;
import com.asashiin.servant.revive.ServantRevive;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;

/**
 * Archer innate skill (VANILLA moveset, bows): the servant draws for a couple of seconds, then fires a volley.
 * Arrow count grows and the delay between arrows shrinks with level. Movement is never touched, so archers keep
 * walking away from close targets (the Servant mod's own retreat) while they charge and shoot.
 *
 * How it hooks in: the Servant mod's bow loop ends every draw with ServantEntity.performRangedAttack(). The
 * ServantRangedMixin sends that call here first. When the skill is ready the normal shot is swallowed and the
 * charge starts; while the skill is running further normal shots are swallowed too. The volley itself calls
 * performRangedAttack() once per arrow (one arrow consumed, one arrow spawned, exactly like a normal shot).
 */
public final class RapidShot {
    private static final String NBT_READY = "sc_rapid_ready";

    private static final class State {
        long start;
        boolean firing;
        int left;
        int gap;
        int delay;
        int blind;
    }

    private static final Map<ServantEntity, State> STATES = new WeakHashMap<>();
    /** True while our own volley arrows go through performRangedAttack, so the mixin lets them pass. */
    private static boolean firingVolley;

    private RapidShot() {}

    /**
     * Called by the mixin for every normal bow shot. Returns true to cancel that normal shot.
     */
    public static boolean onNormalShot(ServantEntity servant, LivingEntity target) {
        if (firingVolley || servant.level().isClientSide()) {
            return false;
        }
        if (!ServantCombatConfig.vanilla() || !ServantCombatConfig.RAPID_SHOT.get() || ServantBow.bowHand(servant) == null) {
            return false;
        }
        if (STATES.containsKey(servant)) {
            return true; // charging or mid-volley: the normal shot would only break the charge
        }
        if (target == null || !target.isAlive() || ServantRevive.isDowned(servant)) {
            return false;
        }
        long now = servant.level().getGameTime();
        CompoundTag data = servant.getPersistentData();
        if (now < data.getLong(NBT_READY) || ServantLevels.level(servant) < ServantCombatConfig.RAPID_MIN_LEVEL.get()) {
            return false;
        }
        if (!ServantBow.spend(servant, ServantCombatConfig.RAPID_ENERGY_COST.get())) {
            return false;
        }
        State st = new State();
        st.start = now;
        STATES.put(servant, st);
        if (servant.level() instanceof ServerLevel level) {
            level.playSound(null, servant.getX(), servant.getY(), servant.getZ(),
                SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.NEUTRAL, 0.8F, 1.3F);
        }
        return true;
    }

    /** Runs every tick for every servant (cheap when no volley is active). */
    public static void tick(ServantEntity servant) {
        State st = STATES.get(servant);
        if (st == null) {
            return;
        }
        if (servant.level().isClientSide()) {
            STATES.remove(servant);
            return;
        }
        long now = servant.level().getGameTime();
        LivingEntity target = servant.getTarget();
        InteractionHand hand = ServantBow.bowHand(servant);
        ServantOrder order = servant.getCurrentOrder();
        if (!servant.isAlive() || ServantRevive.isDowned(servant) || hand == null || target == null || !target.isAlive()
            || !ServantCombatConfig.vanilla() || !ServantCombatConfig.RAPID_SHOT.get()
            || (order != ServantOrder.GUARD && order != ServantOrder.FOLLOW)) {
            end(servant, st, now, 0.5);
            return;
        }
        if (servant.hasLineOfSight(target)) {
            st.blind = 0;
        } else if (++st.blind > 20) {
            end(servant, st, now, 0.5);
            return;
        }

        // keep the bow visibly drawn for the whole skill (the Servant mod's own loop releases it after each
        // swallowed shot; this puts it back on the same tick)
        if (!servant.isUsingItem()) {
            servant.startUsingItem(hand);
        }

        if (!st.firing) {
            long charged = now - st.start;
            if (charged % 4 == 0 && servant.level() instanceof ServerLevel level) {
                level.sendParticles(ParticleTypes.CRIT, servant.getX(), servant.getEyeY() - 0.2, servant.getZ(),
                    2, 0.35, 0.25, 0.35, 0.05);
            }
            if (charged < ServantCombatConfig.RAPID_CHARGE_TICKS.get()) {
                return;
            }
            double p = VanillaCombat.progress(servant);
            st.firing = true;
            st.left = Math.max(1, (int) Math.round(Mth.lerp(p, ServantCombatConfig.RAPID_ARROWS_MIN.get(), ServantCombatConfig.RAPID_ARROWS_MAX.get())));
            st.delay = Math.max(1, (int) Math.round(Mth.lerp(p, ServantCombatConfig.RAPID_DELAY_START.get(), ServantCombatConfig.RAPID_DELAY_MIN.get())));
            st.gap = 0;
            if (servant.level() instanceof ServerLevel level) {
                level.playSound(null, servant.getX(), servant.getY(), servant.getZ(),
                    SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.NEUTRAL, 0.8F, 1.5F);
            }
        }

        if (st.gap > 0) {
            st.gap--;
            return;
        }
        firingVolley = true;
        try {
            servant.performRangedAttack(target, 1.0F);
        } finally {
            firingVolley = false;
        }
        st.left--;
        st.gap = Math.max(0, st.delay - 1);
        if (st.left <= 0) {
            end(servant, st, now, 1.0);
        }
    }

    /** Stops the skill and starts the cooldown ({@code cooldownFactor} 1.0 = full, less when it was interrupted). */
    private static void end(ServantEntity servant, State st, long now, double cooldownFactor) {
        STATES.remove(servant);
        if (servant.isUsingItem()) {
            try {
                servant.stopUsingItem();
            } catch (Throwable ignored) {
                // nothing to stop
            }
        }
        double p = VanillaCombat.progress(servant);
        double cooldown = ServantCombatConfig.RAPID_COOLDOWN.get()
            * (1.0 - ServantCombatConfig.RAPID_COOLDOWN_REDUCTION_AT_MAX_LEVEL.get() * p) * cooldownFactor;
        servant.getPersistentData().putLong(NBT_READY, now + Math.max(20L, Math.round(cooldown)));
    }
}
