package com.servantcombat;

import java.util.EnumMap;
import java.util.Map;
import java.util.Locale;
import net.neoforged.neoforge.common.ModConfigSpec;

public final class ServantCombatConfig {
    public enum Moveset { EPIC_FIGHT, VANILLA }

    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.EnumValue<Moveset> MOVESET;

    public static final ModConfigSpec.BooleanValue PARRY;
    public static final ModConfigSpec.DoubleValue PARRY_BASE_CHANCE;
    public static final ModConfigSpec.DoubleValue PARRY_CHANCE_AT_MAX_LEVEL;
    public static final ModConfigSpec.IntValue PERFECT_PARRY_MIN_LEVEL;
    public static final ModConfigSpec.DoubleValue PERFECT_PARRY_CHANCE;
    public static final ModConfigSpec.DoubleValue BLOCKED_DAMAGE_MULTIPLIER;
    public static final ModConfigSpec.DoubleValue PARRY_ENERGY_COST_PERCENT;

    public static final ModConfigSpec.BooleanValue DASH;
    public static final ModConfigSpec.DoubleValue DASH_CHANCE_WHEN_HIT;
    public static final ModConfigSpec.DoubleValue DASH_IDLE_CHANCE_PER_TICK;
    public static final ModConfigSpec.IntValue DASH_COOLDOWN_MIN;
    public static final ModConfigSpec.IntValue DASH_COOLDOWN_MAX;
    public static final ModConfigSpec.DoubleValue DASH_STRENGTH;
    public static final ModConfigSpec.IntValue DASH_ENERGY_COST;

    public static final ModConfigSpec.BooleanValue BACKPEDAL;
    public static final ModConfigSpec.DoubleValue BACKPEDAL_SPEED;
    public static final ModConfigSpec.DoubleValue BACKPEDAL_REACH_FRACTION;
    public static final ModConfigSpec.IntValue BACKPEDAL_MIN_COOLDOWN_LEFT;
    public static final ModConfigSpec.DoubleValue BACKPEDAL_SIDE_STEP;

    public static final ModConfigSpec.BooleanValue CREEPER_EVADE;
    public static final ModConfigSpec.IntValue CREEPER_FUSE_THRESHOLD;
    public static final ModConfigSpec.DoubleValue CREEPER_DANGER_RADIUS;
    public static final ModConfigSpec.DoubleValue CREEPER_DASH_STRENGTH;
    public static final ModConfigSpec.IntValue CREEPER_DASH_COOLDOWN;

    public static final ModConfigSpec.BooleanValue CRIT;
    public static final ModConfigSpec.DoubleValue CRIT_CHANCE_BASE;
    public static final ModConfigSpec.DoubleValue CRIT_CHANCE_AT_MAX_LEVEL;
    public static final ModConfigSpec.DoubleValue CRIT_MULTIPLIER;

    public static final ModConfigSpec.BooleanValue RAPID_SHOT;
    public static final ModConfigSpec.IntValue RAPID_MIN_LEVEL;
    public static final ModConfigSpec.IntValue RAPID_CHARGE_TICKS;
    public static final ModConfigSpec.IntValue RAPID_ARROWS_MIN;
    public static final ModConfigSpec.IntValue RAPID_ARROWS_MAX;
    public static final ModConfigSpec.IntValue RAPID_DELAY_START;
    public static final ModConfigSpec.IntValue RAPID_DELAY_MIN;
    public static final ModConfigSpec.IntValue RAPID_COOLDOWN;
    public static final ModConfigSpec.DoubleValue RAPID_COOLDOWN_REDUCTION_AT_MAX_LEVEL;
    public static final ModConfigSpec.IntValue RAPID_ENERGY_COST;

    public static final ModConfigSpec.DoubleValue ATTACK_SPEED_BONUS_AT_MAX_LEVEL;

    public static final ModConfigSpec.BooleanValue WEAPON_STATS;
    private static final Map<InnateSkills.Weapon, ModConfigSpec.DoubleValue[]> STATS = new EnumMap<>(InnateSkills.Weapon.class);

    public static final ModConfigSpec.BooleanValue SKILLS;
    public static final ModConfigSpec.DoubleValue SKILL_CHANCE_PER_TICK;
    public static final ModConfigSpec.IntValue SKILL_COOLDOWN;
    public static final ModConfigSpec.DoubleValue SKILL_COOLDOWN_REDUCTION_AT_MAX_LEVEL;
    public static final ModConfigSpec.IntValue SKILL_MIN_LEVEL;
    public static final ModConfigSpec.IntValue SKILL_ENERGY_COST;
    public static final ModConfigSpec.DoubleValue SKILL_DAMAGE_MULTIPLIER;
    public static final ModConfigSpec.ConfigValue<String> KW_UCHIGATANA;
    public static final ModConfigSpec.ConfigValue<String> KW_TACHI;
    public static final ModConfigSpec.ConfigValue<String> KW_GREATSWORD;
    public static final ModConfigSpec.ConfigValue<String> KW_LONGSWORD;
    public static final ModConfigSpec.ConfigValue<String> KW_DAGGER;
    public static final ModConfigSpec.ConfigValue<String> KW_SPEAR;
    public static final ModConfigSpec.ConfigValue<String> KW_SWORD;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();

        MOVESET = b.comment(
                "Servant combat style.",
                "EPIC_FIGHT = servants keep their Epic Fight moveset (default).",
                "VANILLA    = vanilla player animations + vanilla combat (weapon parry, dashes, sweeping attack,",
                "             attack speed that grows with level). Only matters when Epic Fight is installed.",
                "Dedicated servers: use the same value on the server and on every client.")
            .defineEnum("moveset", Moveset.EPIC_FIGHT);

        b.push("vanilla_parry");
        PARRY = b.comment("Servants block/parry melee hits with their weapon (GUARD / FOLLOW orders).")
            .define("enabled", true);
        PARRY_BASE_CHANCE = b.comment("Parry chance at level 1.")
            .defineInRange("baseChance", 0.55, 0.0, 1.0);
        PARRY_CHANCE_AT_MAX_LEVEL = b.comment("Parry chance at max level (level 50). Scales linearly with level.")
            .defineInRange("chanceAtMaxLevel", 0.90, 0.0, 1.0);
        PERFECT_PARRY_MIN_LEVEL = b.comment("From this level a parry can be a perfect parry (negates the hit, staggers the attacker).")
            .defineInRange("perfectParryMinLevel", 30, 1, 50);
        PERFECT_PARRY_CHANCE = b.comment("Chance that a parry is a perfect parry once the level requirement is met.")
            .defineInRange("perfectParryChance", 0.5, 0.0, 1.0);
        BLOCKED_DAMAGE_MULTIPLIER = b.comment("Damage multiplier for a normal (non-perfect) block. 0.25 = takes 25% damage.")
            .defineInRange("blockedDamageMultiplier", 0.25, 0.0, 1.0);
        PARRY_ENERGY_COST_PERCENT = b.comment("Servant energy spent per parry, as a fraction of max energy (shared with the archer dash energy).")
            .defineInRange("energyCostPercent", 0.20, 0.0, 1.0);
        b.pop();

        b.push("vanilla_dash");
        DASH = b.comment("Servants may dash back / left / right in melee range. Archers keep the Servant mod's own dash.")
            .define("enabled", true);
        DASH_CHANCE_WHEN_HIT = b.comment("Chance to dash right after being hit.")
            .defineInRange("chanceWhenHit", 0.30, 0.0, 1.0);
        DASH_IDLE_CHANCE_PER_TICK = b.comment("Chance per tick to dash on their own while an enemy is in melee range.")
            .defineInRange("idleChancePerTick", 0.006, 0.0, 1.0);
        DASH_COOLDOWN_MIN = b.comment("Minimum ticks between dashes.")
            .defineInRange("cooldownMinTicks", 50, 0, 1200);
        DASH_COOLDOWN_MAX = b.comment("Maximum ticks between dashes.")
            .defineInRange("cooldownMaxTicks", 90, 0, 1200);
        DASH_STRENGTH = b.comment("Horizontal dash speed.")
            .defineInRange("strength", 0.85, 0.1, 3.0);
        DASH_ENERGY_COST = b.comment("Servant energy spent per dash.")
            .defineInRange("energyCost", 20, 0, 1000);
        b.pop();

        b.push("vanilla_backpedal");
        BACKPEDAL = b.comment(
                "Melee servants step backward (a little sideways too) while their attack recharges, like a player",
                "spacing a fight, then step back in for the next hit. Creepers are handled by [vanilla_creeper_evade].")
            .define("enabled", true);
        BACKPEDAL_SPEED = b.comment("Backward walking speed in blocks per tick (0.14 is about 2.8 blocks/second).")
            .defineInRange("speed", 0.14, 0.02, 0.5);
        BACKPEDAL_REACH_FRACTION = b.comment(
                "They only back up while the target is closer than (melee reach x this). Reach includes the weapon's",
                "reach bonus, so long weapons keep a longer distance.")
            .defineInRange("distanceFractionOfReach", 0.8, 0.3, 1.0);
        BACKPEDAL_MIN_COOLDOWN_LEFT = b.comment("Only back up while at least this many ticks of attack cooldown are left (so they are back in reach when ready).")
            .defineInRange("minCooldownTicksLeft", 4, 0, 40);
        BACKPEDAL_SIDE_STEP = b.comment("Sideways part of the retreat, 0 = straight back, 0.35 = slight circle-strafe.")
            .defineInRange("sideStep", 0.35, 0.0, 1.0);
        b.pop();

        b.push("vanilla_creeper_evade");
        CREEPER_EVADE = b.comment(
                "Servants dash straight away from a creeper that is close to exploding, and do not walk back into it",
                "while it is still swelling. Works for every servant, not only melee ones.")
            .define("enabled", true);
        CREEPER_FUSE_THRESHOLD = b.comment("Ticks a creeper must already have been swelling before the servant dashes (a creeper explodes after 30).")
            .defineInRange("fuseTicksBeforeDash", 10, 0, 30);
        CREEPER_DANGER_RADIUS = b.comment("Only dash when the creeper is closer than this many blocks (x1.5 for charged creepers).")
            .defineInRange("dangerRadius", 6.5, 3.0, 16.0);
        CREEPER_DASH_STRENGTH = b.comment("Horizontal dash speed away from the creeper (1.0 is roughly 6 blocks).")
            .defineInRange("dashStrength", 1.0, 0.2, 3.0);
        CREEPER_DASH_COOLDOWN = b.comment("Ticks before the servant may dash away again.")
            .defineInRange("cooldownTicks", 10, 0, 200);
        b.pop();

        b.push("vanilla_crit");
        CRIT = b.comment(
                "Melee crits for servants. No jumping needed: every hit rolls the chance, on the ground too.",
                "The chance grows linearly from level 1 to level 50. Innate skills do not roll crits.")
            .define("enabled", true);
        CRIT_CHANCE_BASE = b.comment("Crit chance at level 1.")
            .defineInRange("chanceAtLevel1", 0.05, 0.0, 1.0);
        CRIT_CHANCE_AT_MAX_LEVEL = b.comment("Crit chance at level 50.")
            .defineInRange("chanceAtMaxLevel", 0.45, 0.0, 1.0);
        CRIT_MULTIPLIER = b.comment("Damage multiplier on a crit (vanilla player crit = 1.5).")
            .defineInRange("damageMultiplier", 1.5, 1.0, 5.0);
        b.pop();

        b.push("rapid_shot");
        RAPID_SHOT = b.comment(
                "Archer innate skill (bows, VANILLA moveset): the servant draws for a while, then fires a volley.",
                "The arrow count grows and the delay between arrows shrinks with level (level 1 -> level 50).",
                "Every arrow uses one arrow from the servant's inventory and damages the bow.")
            .define("enabled", true);
        RAPID_MIN_LEVEL = b.comment("Servant level required to unlock rapid shot.")
            .defineInRange("minLevel", 1, 1, 50);
        RAPID_CHARGE_TICKS = b.comment("Charge time before the volley (40 ticks = 2 seconds).")
            .defineInRange("chargeTicks", 40, 1, 400);
        RAPID_ARROWS_MIN = b.comment("Arrows per volley at level 1.")
            .defineInRange("arrowsAtLevel1", 3, 1, 20);
        RAPID_ARROWS_MAX = b.comment("Arrows per volley at level 50.")
            .defineInRange("arrowsAtMaxLevel", 6, 1, 20);
        RAPID_DELAY_START = b.comment("Ticks between arrows at level 1 (12 ticks = 0.6 seconds).")
            .defineInRange("delayTicksAtLevel1", 12, 1, 100);
        RAPID_DELAY_MIN = b.comment("Ticks between arrows at level 50 (6 ticks = 0.3 seconds).")
            .defineInRange("delayTicksAtMaxLevel", 6, 1, 100);
        RAPID_COOLDOWN = b.comment("Ticks between volleys at level 1 (counted from the end of the volley).")
            .defineInRange("cooldownTicks", 160, 20, 12000);
        RAPID_COOLDOWN_REDUCTION_AT_MAX_LEVEL = b.comment("Cooldown reduction at level 50 (0.4 = 40% shorter).")
            .defineInRange("cooldownReductionAtMaxLevel", 0.4, 0.0, 0.9);
        RAPID_ENERGY_COST = b.comment("Servant energy spent when the charge starts.")
            .defineInRange("energyCost", 30, 0, 1000);
        b.pop();

        b.push("vanilla_attack_speed");
        ATTACK_SPEED_BONUS_AT_MAX_LEVEL = b.comment(
                "Extra attack speed (multiplier on the final value) at level 50, scaled linearly from level 1 (0).",
                "Added on top of the Servant mod's own level scaling. 0.5 = +50% at max level.")
            .defineInRange("bonusAtMaxLevel", 0.5, 0.0, 5.0);
        b.pop();

        b.push("vanilla_weapon_stats");
        WEAPON_STATS = b.comment(
                "Per weapon type basic-attack stats in VANILLA mode (weapon type is detected from the item id, see",
                "[vanilla_innate_skills] keywords). They stack on top of the item's own attributes.",
                "attackSpeedMultiplier : multiplies the final attack speed (2.0 = twice as fast)",
                "damageMultiplier      : multiplies the final attack damage",
                "reachBonus            : added to the servant's melee reach (blocks); they start swinging from further away",
                "sweepRatioBonus       : added to the sweep damage ratio (only for weapons that can sweep, e.g. swords)")
            .define("enabled", true);
        for (InnateSkills.Weapon w : InnateSkills.Weapon.values()) {
            double[] d = defaults(w);
            b.push(w.name().toLowerCase(Locale.ROOT));
            STATS.put(w, new ModConfigSpec.DoubleValue[] {
                b.defineInRange("attackSpeedMultiplier", d[0], 0.1, 5.0),
                b.defineInRange("damageMultiplier", d[1], 0.1, 5.0),
                b.defineInRange("reachBonus", d[2], -2.0, 4.0),
                b.defineInRange("sweepRatioBonus", d[3], -1.0, 3.0)
            });
            b.pop();
        }
        b.pop();

        b.push("vanilla_innate_skills");
        SKILLS = b.comment("Weapon innate skills in VANILLA mode (sword, dagger, spear, longsword, greatsword, tachi, uchigatana).")
            .define("enabled", true);
        SKILL_CHANCE_PER_TICK = b.comment("Chance per tick to cast a skill while an enemy is in that weapon's skill range (off cooldown).")
            .defineInRange("chancePerTick", 0.02, 0.0, 1.0);
        SKILL_COOLDOWN = b.comment("Base ticks between skills (20 ticks = 1 second).")
            .defineInRange("cooldownTicks", 140, 20, 12000);
        SKILL_COOLDOWN_REDUCTION_AT_MAX_LEVEL = b.comment("Cooldown reduction at level 50 (0.4 = 40% shorter). Scales linearly with level.")
            .defineInRange("cooldownReductionAtMaxLevel", 0.4, 0.0, 0.9);
        SKILL_MIN_LEVEL = b.comment("Servant level required before innate skills unlock.")
            .defineInRange("minLevel", 1, 1, 50);
        SKILL_ENERGY_COST = b.comment("Servant energy spent per skill.")
            .defineInRange("energyCost", 30, 0, 1000);
        SKILL_DAMAGE_MULTIPLIER = b.comment("Global damage multiplier for all innate skills.")
            .defineInRange("damageMultiplier", 1.0, 0.0, 10.0);
        b.comment("Weapon detection: a weapon belongs to a type when its item id PATH contains one of these words",
                "(comma separated, case-insensitive; 'iron_greatsword' or 'somemod:holy_tachi' both match).",
                "Types are checked in this order: uchigatana, tachi, greatsword, longsword, dagger, spear, sword,",
                "so a 'greatsword' is never mistaken for a plain 'sword'. Leave a list empty to disable that type.");
        KW_UCHIGATANA = b.define("uchigatana", "uchigatana,katana");
        KW_TACHI = b.define("tachi", "tachi");
        KW_GREATSWORD = b.define("greatsword", "greatsword,great_sword,claymore,zweihander");
        KW_LONGSWORD = b.define("longsword", "longsword,long_sword");
        KW_DAGGER = b.define("dagger", "dagger,knife,kunai");
        KW_SPEAR = b.define("spear", "spear,lance,halberd,glaive,pike");
        KW_SWORD = b.define("sword", "sword,rapier,saber,sabre,scimitar,cutlass");
        b.pop();

        SPEC = b.build();
    }

    private ServantCombatConfig() {}

    /** {attackSpeedMultiplier, damageMultiplier, reachBonus, sweepRatioBonus} */
    private static double[] defaults(InnateSkills.Weapon w) {
        return switch (w) {
            case DAGGER ->     new double[] {1.60, 0.75, -0.25, 0.00};
            case SWORD ->      new double[] {1.00, 1.00,  0.00, 0.00};
            case SPEAR ->      new double[] {0.90, 1.00,  1.00, 0.00};
            case LONGSWORD ->  new double[] {0.80, 1.15,  0.90, 0.25};
            case GREATSWORD -> new double[] {0.60, 1.40,  1.20, 0.60};
            case TACHI ->      new double[] {0.85, 1.20,  0.80, 0.20};
            case UCHIGATANA -> new double[] {1.20, 0.95,  0.50, 0.10};
        };
    }

    /** stat: 0 = attack speed x, 1 = damage x, 2 = reach +, 3 = sweep ratio +. */
    public static double stat(InnateSkills.Weapon weapon, int stat) {
        try {
            return STATS.get(weapon)[stat].get();
        } catch (Throwable t) {
            return stat <= 1 ? 1.0 : 0.0;
        }
    }

    public static String keywords(InnateSkills.Weapon weapon) {
        try {
            return switch (weapon) {
                case UCHIGATANA -> KW_UCHIGATANA.get();
                case TACHI -> KW_TACHI.get();
                case GREATSWORD -> KW_GREATSWORD.get();
                case LONGSWORD -> KW_LONGSWORD.get();
                case DAGGER -> KW_DAGGER.get();
                case SPEAR -> KW_SPEAR.get();
                case SWORD -> KW_SWORD.get();
            };
        } catch (Throwable t) {
            return "";
        }
    }

    /** True when servants should use the vanilla moveset. Safe to call before the config is loaded. */
    public static boolean vanilla() {
        try {
            return MOVESET.get() == Moveset.VANILLA;
        } catch (Throwable t) {
            return false;
        }
    }
}
