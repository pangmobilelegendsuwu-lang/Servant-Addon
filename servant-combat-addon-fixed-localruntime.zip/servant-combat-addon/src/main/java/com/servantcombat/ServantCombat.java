package com.servantcombat;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;

@Mod(ServantCombat.MOD_ID)
public class ServantCombat {
    public static final String MOD_ID = "servantcombat";

    public ServantCombat(IEventBus modBus, ModContainer container) {
        container.registerConfig(ModConfig.Type.COMMON, ServantCombatConfig.SPEC);
        VanillaCombat.register();
    }
}
