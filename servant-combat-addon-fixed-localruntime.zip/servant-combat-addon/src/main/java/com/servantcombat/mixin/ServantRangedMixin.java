package com.servantcombat.mixin;

import com.asashiin.servant.entity.ServantEntity;
import com.servantcombat.RapidShot;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Every normal bow shot of a servant ends in ServantEntity.performRangedAttack(). Rapid shot (VANILLA moveset)
 * takes over that call: it swallows the normal shot to start its charge, and fires the volley itself later.
 */
@Mixin(value = ServantEntity.class, remap = false)
public abstract class ServantRangedMixin {

    @Inject(method = "performRangedAttack", at = @At("HEAD"), cancellable = true, remap = false)
    private void servantcombat$rapidShot(LivingEntity target, float power, CallbackInfo ci) {
        if (RapidShot.onNormalShot((ServantEntity) (Object) this, target)) {
            ci.cancel();
        }
    }
}
