package com.servantcombat.mixin;

import com.asashiin.servant.entity.ServantEntity;
import com.servantcombat.VanillaCombat;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Footwork for the Servant mod's melee goal (VANILLA moveset): walk backward while the attack recharges and
 * never walk into a creeper that is about to explode. The goal's own attack code is left alone, only its
 * "path toward the target" step is skipped on ticks where the servant is stepping back.
 */
@Mixin(targets = "com.asashiin.servant.entity.ServantEntity$GuardMeleeAttackGoal", remap = false)
public abstract class ServantMeleeGoalMixin {

    @Shadow
    @Final
    private ServantEntity servant;

    @Shadow
    private int attackCooldown;

    @Inject(method = "updatePathToTarget", at = @At("HEAD"), cancellable = true, remap = false)
    private void servantcombat$spacing(LivingEntity target, boolean canSee, CallbackInfo ci) {
        if (VanillaCombat.meleeSpacing(this.servant, target, this.attackCooldown)) {
            ci.cancel();
        }
    }
}
