package com.servantcombat.mixin;

import com.servantcombat.ServantCombatConfig;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Turns the Servant mod's Epic Fight patch into a no-op when the config says VANILLA.
 * Targets are strings, so this only loads when Epic Fight (and therefore ServantPatch) is present.
 */
@Mixin(targets = "com.asashiin.servant.epicfight.ServantPatch", remap = false)
public abstract class ServantPatchMixin {

    /** false = Epic Fight does not take over rendering, the normal vanilla player-model renderer is used
     *  (vanilla sit / sleep / swing / walk animations). */
    @Inject(method = "overrideRender", at = @At("HEAD"), cancellable = true, remap = false)
    private void servantcombat$vanillaRender(CallbackInfoReturnable<Boolean> cir) {
        if (ServantCombatConfig.vanilla()) {
            cir.setReturnValue(false);
        }
    }

    /** false = ServantEfBridge.meleeTarget() hands the target back and the Servant mod's own vanilla melee runs. */
    @Inject(method = "tryAttack", at = @At("HEAD"), cancellable = true, remap = false)
    private void servantcombat$noEfAttack(LivingEntity target, CallbackInfoReturnable<Boolean> cir) {
        if (ServantCombatConfig.vanilla()) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "tickDodge", at = @At("HEAD"), cancellable = true, remap = false)
    private void servantcombat$noEfDodge(CallbackInfo ci) {
        if (ServantCombatConfig.vanilla()) ci.cancel();
    }

    @Inject(method = "tickForcedAttack", at = @At("HEAD"), cancellable = true, remap = false)
    private void servantcombat$noEfForcedAttack(CallbackInfo ci) {
        if (ServantCombatConfig.vanilla()) ci.cancel();
    }

    @Inject(method = "tickSeries", at = @At("HEAD"), cancellable = true, remap = false)
    private void servantcombat$noEfSeries(CallbackInfo ci) {
        if (ServantCombatConfig.vanilla()) ci.cancel();
    }

    @Inject(method = "tickArcherSwap", at = @At("HEAD"), cancellable = true, remap = false)
    private void servantcombat$noEfArcherSwap(CallbackInfo ci) {
        if (ServantCombatConfig.vanilla()) ci.cancel();
    }

    /** The +1.2 attack speed the Epic Fight mode adds. Vanilla mode uses level scaling instead. */
    @Inject(method = "applySpeedBoost", at = @At("HEAD"), cancellable = true, remap = false)
    private void servantcombat$noEfSpeedBoost(CallbackInfo ci) {
        if (ServantCombatConfig.vanilla()) ci.cancel();
    }
}
