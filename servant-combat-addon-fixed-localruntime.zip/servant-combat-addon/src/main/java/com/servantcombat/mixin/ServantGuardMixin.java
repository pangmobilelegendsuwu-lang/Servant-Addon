package com.servantcombat.mixin;

import com.servantcombat.ServantCombatConfig;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Disables the Epic Fight guard animation/parry in VANILLA mode (the addon's own parry replaces it). */
@Mixin(targets = "com.asashiin.servant.epicfight.ServantGuard", remap = false)
public abstract class ServantGuardMixin {

    @Inject(method = "onIncoming", at = @At("HEAD"), cancellable = true, remap = false)
    private static void servantcombat$vanillaGuard(LivingIncomingDamageEvent event, CallbackInfoReturnable<Boolean> cir) {
        if (ServantCombatConfig.vanilla()) {
            cir.setReturnValue(false);
        }
    }
}
